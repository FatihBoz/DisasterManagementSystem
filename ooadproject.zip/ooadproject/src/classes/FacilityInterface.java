package classes;

import javax.swing.Icon;
import javax.swing.ImageIcon;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */

/**
 *
 * @author gokay
 */
public interface FacilityInterface {
    public void createFacilities();
    public String getName();
    public String getAdress();
    public void setName();
    public void setAdress();
    public String getID();
    public Icon getIcon();
    
}
